import React from 'react';
class App extends React.Component {
    constructor() {
        super();
        
    }
    render() {
        return <div className=''>
          <h1>这是404页面</h1>
        </div>;
    }
}

export default App