let obj = require('./1')

console.log('这时2.js文件',obj);

module.exports = {
  qqq:1,
  aaa:2
}