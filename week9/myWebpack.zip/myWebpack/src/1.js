let a = 123;
let b = 234;
module.exports = {
  a,b
}