let obj = require('./2')
console.log(obj);